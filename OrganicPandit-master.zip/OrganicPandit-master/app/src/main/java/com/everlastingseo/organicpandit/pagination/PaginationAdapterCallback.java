package com.everlastingseo.organicpandit.pagination;

public interface PaginationAdapterCallback {
    void retryPageLoad();
}
